<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Gopay
 *
 * @package App\Models
 */
class Gopay extends Model
{
    protected $table = 'gopay';
    public $timestamps = false;

    protected $casts = [
        'date' => 'datetime'
    ];

    protected $fillable = [
        'issaved',
        'isfailed',
        'myref',
        'ref',
        'paydata',
        'date'
    ];
}
