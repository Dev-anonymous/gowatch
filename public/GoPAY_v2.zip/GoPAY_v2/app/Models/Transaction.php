<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Transaction
 *
 * @package App\Models
 */
class Transaction extends Model
{
    protected $table = 'transaction';
    public $timestamps = false;

    protected $casts = [
        'date' => 'datetime'
    ];

    protected $fillable = [
        'amount',
        'devise',
        'telephone',
        'ref',
        'paydata',
        'date',
    ];
}
